<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="styles.css">
  <title>Message</title>
</head>
<body>
  <div class="containerAbsente">
    <div class="row">
      <div class="col">
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">Message</h5>
            <p><?php echo $message; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
