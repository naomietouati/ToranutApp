<?php
ob_start();
?>
<html>
<head>
  <title>Toranut Project's</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <header>
    <img src="images/logo2.png" alt="Votre photo" class="logo">
  </header>
</body>
<footer>
    <p>&copy; 2023 Touati Naomie. Tous droits réservés.</p>
</footer>
</html>
